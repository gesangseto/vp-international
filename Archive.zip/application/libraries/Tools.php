<?php

class Tools
{
    private $CI;

    public function __construct()
    {
        $this->CI = &get_instance();
    }

    public function convertDateTime($date, $format = 'Y-m-d')
    {
        $timezone = 'Asia/Jakarta';
        $tzLocal = 'UTC';
        $d = new DateTime($date, new DateTimeZone($tzLocal));
        $d->setTimeZone(new DateTimeZone($timezone));
        return $d->format($format);
    }

    public function action($value = null, $id = null)
    {
        $path = '/vp_international/';
        // change path if error with button
        $url = str_replace($path, "", $_SERVER['REQUEST_URI']);
        $data['menu'] = $_SESSION["menu"];
        $button = '';
        foreach ($data['menu'] as $row) {
            foreach ($row['children'] as $row_children) {
                //var_dump('/'.$row['menu_url'] . '/' . $row_children['child_url']);
                //var_dump($url);
                //die;
                if ($row['menu_url'] . '/' . $row_children['child_url'] ==  $url) { //ini untuk localhost
                    // if ('/' . $row['menu_url'] . '/' . $row_children['child_url'] ==  $url) { // ini untuk server
                    if ($value == 'create' && $row_children['create'] == '1') {
                        $button = '<a  href="' . site_url($url . '/create') . '" class="btn btn-primary"><i class="fas fa-plus fa-sm text-white-50"></i> Tambah</a>';
                    } elseif ($value == 'read'  && $row_children['read'] == '1') {
                        $button = '<a href="' . site_url($url . '/read?id=' . $id) . '" class="btn btn-info btn-sm"><i class="fas fa-search"></i></a>';
                    } elseif ($value == 'update'  && $row_children['update'] == '1') {
                        $button = '<a  href="' . site_url($url . '/update?id=' . $id) . '" class="btn btn-warning btn-sm"><i class="fas fa-pen"></i></a>';
                    } elseif ($value == 'delete'  && $row_children['delete'] == '1') {
                        $button = '<button onclick="hapus(' . $id . ')" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>';
                    }
                }
            }
        }
        return  $button;
    }


    /*
    ===========================
    ini tools untuk fingerprint
    ===========================
    */
    public function read_device()
    {
        $path = 'finger_data/';
        $filename = 'store_device.json';
        $data = json_decode(file_get_contents($path . $filename), true);
        return $data;
    }

    public function store_device($data)
    {
        $path = 'finger_data/';
        $filename = 'store_device.json';
        $current_device = $this->read_device();
        if (@$current_device['finger_device'] == null) {
            $value['finger_device'] = [$data];
            file_put_contents($path . $filename, json_encode($value));
        } else {
            $search_exist = 0;
            $count = 0;
            foreach (@$current_device['finger_device'] as $row) {
                $temp[] = $row;
                if ($row['SN'] == @$data['SN']) {
                    $current_device['finger_device'][$count] = $data;
                    $search_exist = $search_exist + 1;
                }
                $count = $count + 1;
            }
            if ($search_exist == '0') {
                $temp[] = $data;
                $value['finger_device'] = $temp;
                file_put_contents($path . $filename, json_encode($value));
            } else {
                file_put_contents($path . $filename, json_encode($current_device));
            }
        }
        return true;
    }
    public function parse($data, $p1, $p2)
    {
        $data = " " . $data;
        $hasil = "";
        $awal = strpos($data, $p1);
        if ($awal != "") {
            $akhir = strpos(strstr($data, $p1), $p2);
            if ($akhir != "") {
                $hasil = substr($data, $awal + strlen($p1), $akhir - strlen($p1));
            }
        }
        return $hasil;
    }
    public function read_transaction($date = null)
    {
        if ($date == null) {
            $d = date("Y-m-d");
        } else {
            $d = $date;
        }
        $d = $this->convertDateTime($d, 'Ymd');
        $path = 'finger_data/transaction/';
        $filename = 'transaction_' . $d . '.txt';
        $data = file_get_contents($path . $filename);
        return $data;
    }
    public function store_transaction($data, $date = null)
    {
        $d = date("Y-m-d");
        if ($date != null) {
            $d = $date;
        }
        $d = $this->convertDateTime($d, 'Ymd');
        $path = 'finger_data/transaction/';
        $filename = 'transaction_' . $d . '.txt';
        file_put_contents($path . $filename, $data);
        return true;
    }
    public function store_live_transaction($data)
    {
        $path = 'finger_data/transaction/live/';
        $filename = 'live_transaction.txt';
        file_put_contents($path . $filename, $data);
        return true;
    }
    public function store_user($data)
    {
        $path = 'finger_data/';
        $filename = 'store_user.json';
        file_put_contents($path . $filename, $data);
        return true;
    }
    public function read_user($data)
    {
        $path = 'finger_data/';
        $filename = 'store_user.json';
        file_put_contents($path . $filename, $data);
        return true;
    }
}
